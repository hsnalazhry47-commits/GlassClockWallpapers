# Glass Clock Wallpapers

تطبيق Android مستقل لعرض ساعة رقمية بتأثير Liquid Glass وحفظها كخلفية بدقة 1080×2400.

## الخصائص

- Kotlin وJetpack Compose، دون تسجيل دخول أو إعلانات أو دفع.
- يعمل دون إنترنت بعد اكتمال بناء التطبيق وتثبيته.
- تحديث الساعة تلقائيًا عند بداية كل دقيقة بصيغة `HH:mm` في المعاينة، وكذلك بعد تعيين الخلفية الحية عبر `WallpaperService`.
- رسم متجهي مباشر باستخدام Android Canvas: تدرجات، توهجات زرقاء/بنفسجية، طبقات زجاجية، حواف وانعكاسات ضوئية.
- معاينة فورية وزر واحد فقط: **تعيين كخلفية**.
- حفظ PNG في `Pictures/GlassClockWallpapers` ثم فتح معاينة الخلفية الحية في Android؛ وعند عدم توفرها تتم محاولة فتح اختيار الصورة الثابتة.
- واجهة RTL عربية، ومقاس تصدير PNG هو 1080×2400. تنبيه: هذه الأبعاد تعادل نسبة 9:20 (وليست 9:16 حسابيًا)، وقد تم الحفاظ على الأبعاد الرقمية المحددة مع تثبيت تناسب الرسم عند عرضه كخلفية حية.

## متطلبات البناء

- JDK 17 أو أحدث (تم إعداد Gradle لاستهداف JVM 17).
- Android SDK مع Android SDK Platform 35 وBuild Tools المناسبة.
- اتصال إنترنت أول مرة لتنزيل Gradle ومكونات Android Gradle Plugin وCompose؛ التطبيق نفسه لا يحتاج إلى الإنترنت.

## خطوات بناء APK على الكمبيوتر

1. ثبّت Android Studio على Windows أو macOS أو Linux.
2. من SDK Manager داخل Android Studio ثبّت Android SDK Platform 35 وAndroid SDK Build-Tools.
3. ثبّت JDK 17 أو أحدث، ثم افتح مجلد `GlassClockWallpapers` في Android Studio.
4. اسمح بمزامنة Gradle مع اتصال إنترنت؛ أول بناء يحتاج تنزيل Gradle ومكتبات Android، وبعد ذلك يمكن بناء التطبيق دون اتصال إذا اكتملت التنزيلات.
5. افتح Terminal داخل مجلد المشروع وشغّل الأمر المناسب لنظامك:

Linux أو macOS:

```bash
chmod +x ./gradlew
./gradlew :app:copyGlassClockDebugApk
```

Windows:

```bat
gradlew.bat :app:copyGlassClockDebugApk
```

ينشئ Gradle نسخة التثبيت Debug، ثم ينسخها إلى:

```text
build/outputs/apk/glass-clock-debug.apk
```

ويوجد أيضًا APK الأصلي في:

```text
app/build/outputs/apk/debug/app-debug.apk
```

لتثبيت النسخة على جهاز متصل عبر USB مع تفعيل USB debugging:

```bash
adb install -r build/outputs/apk/glass-clock-debug.apk
```

> ملاحظة بيئة العمل: لم يتوفر Android SDK أو Gradle في بيئة إنشاء هذا التسليم، كما تعذر الوصول إلى مستودعات الإنترنت لتنزيلهما. لذلك لم يتم إنشاء APK هنا. ملف `gradlew` المرفق يقوم باستخدام Gradle المحلي أو تنزيل Gradle 8.9 عند تشغيله في بيئة متصلة، لكنه لا يغني عن تثبيت Android SDK 35.


## بناء APK سحابيًا من الهاتف عبر GitHub Actions

أُضيف سير عمل GitHub Actions في `.github/workflows/android.yml`. لا يحتاج إلى Android Studio أو Gradle Wrapper محلي.

1. من متصفح الهاتف افتح https://github.com/new وأنشئ مستودعًا جديدًا (يمكن أن يكون Public أو Private).
2. افتح المستودع، اختر **Add file → Upload files**، وارفع محتويات هذا المجلد كاملة، بما فيها المجلد المخفي `.github/workflows`، ثم اضغط **Commit changes**. تأكد أن `build.gradle.kts` و`settings.gradle.kts` في جذر المستودع، وليس داخل مجلد إضافي.
3. افتح تبويب **Actions** في المستودع. وافق على تفعيل Actions إذا طُلب ذلك. سيبدأ البناء تلقائيًا بعد رفع الملفات. ويمكن تشغيله يدويًا من **Build Glass Clock Wallpapers APK → Run workflow**.
4. افتح أحدث تشغيل وانتظر حتى تصبح النتيجة خضراء (Success).
5. من صفحة التشغيل، انزل إلى **Artifacts** واضغط `glass-clock-debug-apk` لتنزيل ملف ZIP يحتوي على `glass-clock-debug.apk`. فك ضغطه من تطبيق الملفات في الهاتف ثم ثبّت APK.

إذا فشل البناء، افتح خطوة **Build debug APK** وانسخ رسالة الخطأ لإصلاحها. لا ترفع أي مفاتيح توقيع أو أسرار؛ هذا البناء Debug ومناسب للتثبيت التجريبي.
