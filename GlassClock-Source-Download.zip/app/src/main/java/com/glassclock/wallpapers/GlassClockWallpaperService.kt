package com.glassclock.wallpapers

import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.glassclock.wallpapers.render.LiquidGlassRenderer
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** A real live wallpaper engine so the lock/home wallpaper clock can advance every minute. */
class GlassClockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ClockEngine()

    private inner class ClockEngine : Engine() {
        private val mainHandler = Handler(Looper.getMainLooper())
        private var isWallpaperVisible = false

        private val minuteTick = object : Runnable {
            override fun run() {
                if (!isWallpaperVisible) return
                drawFrame()
                scheduleNextMinute()
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            isWallpaperVisible = visible
            if (visible) {
                drawFrame()
                scheduleNextMinute()
            } else {
                mainHandler.removeCallbacks(minuteTick)
            }
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder,
            format: Int,
            width: Int,
            height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            mainHandler.removeCallbacks(minuteTick)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            isWallpaperVisible = false
            mainHandler.removeCallbacks(minuteTick)
            super.onDestroy()
        }

        private fun scheduleNextMinute() {
            mainHandler.removeCallbacks(minuteTick)
            val untilNextMinute = 60_000L - (System.currentTimeMillis() % 60_000L)
            mainHandler.postDelayed(minuteTick, untilNextMinute.coerceAtLeast(250L))
        }

        private fun drawFrame() {
            var targetCanvas: Canvas? = null
            try {
                targetCanvas = surfaceHolder.lockCanvas()
                if (targetCanvas != null) {
                    val timeText = LocalDateTime.now().format(
                        DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT)
                    )
                    LiquidGlassRenderer.draw(
                        canvas = targetCanvas,
                        width = targetCanvas.width.toFloat(),
                        height = targetCanvas.height.toFloat(),
                        timeText = timeText
                    )
                }
            } catch (_: RuntimeException) {
                // The system may temporarily revoke the wallpaper surface while switching screens.
            } finally {
                if (targetCanvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(targetCanvas)
                    } catch (_: RuntimeException) {
                        // Surface was already released by the system.
                    }
                }
            }
        }
    }
}
