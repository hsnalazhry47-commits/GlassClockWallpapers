package com.glassclock.wallpapers

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.app.WallpaperManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.glassclock.wallpapers.render.LiquidGlassRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                GlassClockScreen()
            }
        }
    }
}

@Composable
private fun GlassClockScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var timeLabel by remember { mutableStateOf(currentClockText()) }
    var isSaving by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            timeLabel = currentClockText()
            val now = System.currentTimeMillis()
            val untilNextMinute = 60_000L - (now % 60_000L)
            delay(untilNextMinute.coerceAtLeast(250L))
        }
    }

    androidx.compose.runtime.CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070910))
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 18.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawIntoCanvas { composeCanvas ->
                        LiquidGlassRenderer.draw(
                            canvas = composeCanvas.nativeCanvas,
                            width = size.width,
                            height = size.height,
                            timeText = timeLabel
                        )
                    }
                }
            }

            Button(
                onClick = {
                    if (!isSaving) {
                        isSaving = true
                        scope.launch {
                            try {
                                val savedUri = saveWallpaper(context, timeLabel)
                                openWallpaperPicker(context, savedUri)
                            } catch (error: Exception) {
                                Toast.makeText(
                                    context,
                                    "تعذّر حفظ الخلفية: ${error.localizedMessage ?: "خطأ غير معروف"}",
                                    Toast.LENGTH_LONG
                                ).show()
                            } finally {
                                isSaving = false
                            }
                        }
                    }
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                shape = RoundedCornerShape(22.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD5F2FF),
                    contentColor = Color(0xFF08131D),
                    disabledContainerColor = Color(0xFF7897A8),
                    disabledContentColor = Color(0xFF08131D)
                )
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.padding(vertical = 2.dp),
                        color = Color(0xFF08131D),
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        text = "تعيين كخلفية",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(vertical = 7.dp)
                    )
                }
            }
        }
    }
}

private fun currentClockText(): String =
    LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT))

private suspend fun saveWallpaper(context: Context, timeText: String): Uri =
    withContext(Dispatchers.IO) {
        val bitmap = Bitmap.createBitmap(1080, 2400, Bitmap.Config.ARGB_8888)
        try {
            LiquidGlassRenderer.draw(
                canvas = AndroidCanvas(bitmap),
                width = 1080f,
                height = 2400f,
                timeText = timeText
            )

            val timestamp = LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss", Locale.ROOT)
            )
            val displayName = "GlassClock_$timestamp.png"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "${android.os.Environment.DIRECTORY_PICTURES}/GlassClockWallpapers"
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
                values
            ) ?: throw IOException("لم يتمكن Android من إنشاء ملف الصورة")

            try {
                val output = resolver.openOutputStream(uri, "w")
                    ?: throw IOException("تعذّر فتح ملف الصورة للكتابة")
                output.use { stream ->
                    if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)) {
                        throw IOException("فشل ضغط صورة الخلفية")
                    }
                }
                val readyValues = ContentValues().apply {
                    put(MediaStore.Images.Media.IS_PENDING, 0)
                }
                resolver.update(uri, readyValues, null, null)
                uri
            } catch (error: Exception) {
                resolver.delete(uri, null, null)
                throw error
            }
        } finally {
            bitmap.recycle()
        }
    }

private fun openWallpaperPicker(context: Context, imageUri: Uri) {
    // Prefer the native live-wallpaper preview: it keeps the clock moving after setup.
    val liveWallpaperIntent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
        putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(context, GlassClockWallpaperService::class.java)
        )
    }

    try {
        context.startActivity(liveWallpaperIntent)
        return
    } catch (_: ActivityNotFoundException) {
        // Older or vendor-modified Android builds may not expose the live-wallpaper picker.
    }

    // Fallback: let Android or an installed gallery app set the just-saved PNG as a static image.
    val attachIntent = Intent(Intent.ACTION_ATTACH_DATA).apply {
        setDataAndType(imageUri, "image/png")
        putExtra("mimeType", "image/png")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(Intent.createChooser(attachIntent, "تعيين كخلفية"))
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(
            context,
            "تم حفظ الصورة في Pictures/GlassClockWallpapers",
            Toast.LENGTH_LONG
        ).show()
    }
}
