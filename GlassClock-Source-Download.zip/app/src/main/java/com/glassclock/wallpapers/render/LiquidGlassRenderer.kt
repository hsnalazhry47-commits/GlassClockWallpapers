package com.glassclock.wallpapers.render

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface

/**
 * Shared renderer for the live Compose preview and the exported 1080 x 2400 wallpaper.
 * It deliberately draws every frame from vectors, gradients and paths: no baked-in clock image.
 */
object LiquidGlassRenderer {
    fun draw(canvas: Canvas, width: Float, height: Float, timeText: String) {
        if (width <= 0f || height <= 0f) return

        val rootSave = canvas.save()
        canvas.drawColor(0xFF070910.toInt())
        drawBackground(canvas, width, height)

        // Keep the clock artwork at the requested 9:20 wallpaper proportions even when
        // Android gives a live wallpaper a wider scrolling surface.
        val designWidth = minOf(width, height * 9f / 20f)
        val designHeight = designWidth * 20f / 9f
        val designScale = designWidth / 1080f
        canvas.save()
        canvas.translate((width - designWidth) / 2f, (height - designHeight) / 2f)
        canvas.scale(designScale, designScale)
        drawAtmosphere(canvas, 1080f, 2400f)
        drawGlassClock(canvas, 1080f, 2400f, timeText)
        canvas.restore()
        canvas.restoreToCount(rootSave)
    }

    private fun drawBackground(canvas: Canvas, width: Float, height: Float) {
        val background = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                0f,
                width,
                height,
                intArrayOf(
                    0xFF090C13.toInt(),
                    0xFF080B13.toInt(),
                    0xFF090914.toInt(),
                    0xFF05070C.toInt()
                ),
                floatArrayOf(0f, 0.34f, 0.72f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width, height, background)

        // Soft, broad radial light sources behind the typography.
        drawGlow(canvas, width * 0.5f, height * 0.47f, width * 0.62f,
            intArrayOf(0x303D8DFF, 0x1B4259C8, 0x084C3BE7, 0x00000000))
        drawGlow(canvas, width * 0.13f, height * 0.57f, width * 0.42f,
            intArrayOf(0x263A9EFF, 0x153A60CE, 0x063B4EEA, 0x00000000))
        drawGlow(canvas, width * 0.88f, height * 0.59f, width * 0.43f,
            intArrayOf(0x2A9D55FF, 0x174C3FC8, 0x073D42D8, 0x00000000))
        drawGlow(canvas, width * 0.54f, height * 0.88f, width * 0.55f,
            intArrayOf(0x172D76FF, 0x103F43C7, 0x063D38DB, 0x00000000))
    }

    private fun drawGlow(
        canvas: Canvas,
        centerX: Float,
        centerY: Float,
        radius: Float,
        colors: IntArray
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                centerX,
                centerY,
                radius,
                colors,
                floatArrayOf(0f, 0.38f, 0.72f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawCircle(centerX, centerY, radius, paint)
    }

    private fun drawAtmosphere(canvas: Canvas, width: Float, height: Float) {
        // Very low-contrast elliptical glass contours keep the top safe area quiet.
        val contourPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = width * 0.0022f
            color = 0x123E9FFF
        }
        canvas.drawOval(
            RectF(width * 0.08f, height * 0.31f, width * 0.92f, height * 0.70f),
            contourPaint
        )
        contourPaint.color = 0x0EAB78FF
        contourPaint.strokeWidth = width * 0.0015f
        canvas.drawOval(
            RectF(width * 0.14f, height * 0.35f, width * 0.86f, height * 0.66f),
            contourPaint
        )

        val sweep = Path().apply {
            moveTo(width * 0.02f, height * 0.66f)
            cubicTo(
                width * 0.27f, height * 0.58f,
                width * 0.70f, height * 0.75f,
                width * 0.99f, height * 0.62f
            )
        }
        val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = width * 0.0018f
            shader = LinearGradient(
                0f,
                height * 0.6f,
                width,
                height * 0.7f,
                intArrayOf(0x003D9BFF, 0x2667A8FF, 0x1BBD8EFF, 0x007D58FF),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(sweep, sweepPaint)

        // Small, restrained reflections stay away from the lock-screen icon area.
        val glint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x55B8E8FF
            strokeWidth = width * 0.0018f
            strokeCap = Paint.Cap.ROUND
            style = Paint.Style.STROKE
        }
        canvas.drawLine(width * 0.18f, height * 0.77f, width * 0.34f, height * 0.75f, glint)
        glint.color = 0x4D9C8FFF
        canvas.drawLine(width * 0.70f, height * 0.29f, width * 0.83f, height * 0.27f, glint)
    }

    private fun drawGlassClock(canvas: Canvas, width: Float, height: Float, timeText: String) {
        val typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        val requestedSize = width * 0.248f
        val measuringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.typeface = typeface
            textSize = requestedSize
            textScaleX = 0.96f
        }
        val measuredWidth = measuringPaint.measureText(timeText)
        val textSize = if (measuredWidth > width * 0.90f) {
            requestedSize * (width * 0.90f / measuredWidth)
        } else {
            requestedSize
        }
        measuringPaint.textSize = textSize
        val baseline = height * 0.535f
        val path = Path()
        measuringPaint.getTextPath(
            timeText,
            0,
            timeText.length,
            -measuringPaint.measureText(timeText) / 2f,
            0f,
            path
        )
        val bounds = RectF()
        path.computeBounds(bounds, true)

        val clockSave = canvas.save()
        canvas.translate(width / 2f, baseline)

        // Refracted violet shadow beneath the glass edge.
        val depthShadow = strokePaint(
            color = 0x4A8B60FF,
            strokeWidth = textSize * 0.055f
        )
        canvas.save()
        canvas.translate(0f, textSize * 0.027f)
        canvas.drawPath(path, depthShadow)
        canvas.restore()

        // Multi-pass luminous rim: wide and low-alpha first, crisp edges last.
        canvas.drawPath(
            path,
            strokePaint(0x1E58B8FF, textSize * 0.115f)
        )
        canvas.drawPath(
            path,
            strokePaint(0x3E697CFF, textSize * 0.072f)
        )
        canvas.drawPath(
            path,
            strokePaint(0x6F79CFFF, textSize * 0.028f)
        )

        val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = textSize * 0.019f
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            shader = LinearGradient(
                bounds.left,
                bounds.top,
                bounds.right,
                bounds.bottom,
                intArrayOf(
                    0xF1FFFFFF.toInt(),
                    0xD7C7F7FF.toInt(),
                    0xA77DC8FF.toInt(),
                    0xD5A4A0FF.toInt(),
                    0xEFFFFFFF.toInt()
                ),
                floatArrayOf(0f, 0.23f, 0.52f, 0.78f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(path, rim)

        val glassFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                0f,
                bounds.top,
                0f,
                bounds.bottom,
                intArrayOf(
                    0x48FFFFFF,
                    0x3AC7E8FF,
                    0x269B9BFF,
                    0x3C8B6BE8,
                    0x58E4D9FF
                ),
                floatArrayOf(0f, 0.22f, 0.48f, 0.78f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawPath(path, glassFill)

        // Fine white inner edge adds the laminated, multi-layer glass appearance.
        canvas.drawPath(
            path,
            strokePaint(0x73FFFFFF, textSize * 0.0065f)
        )

        drawGlassReflections(canvas, path, bounds, textSize)
        canvas.restoreToCount(clockSave)

        drawSmallLensFlares(canvas, width, height)
    }

    private fun strokePaint(color: Int, strokeWidth: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        this.strokeWidth = strokeWidth
        this.color = color
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private fun drawGlassReflections(
        canvas: Canvas,
        glyphPath: Path,
        bounds: RectF,
        textSize: Float
    ) {
        val save = canvas.save()
        canvas.clipPath(glyphPath)

        val topReflection = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                bounds.top,
                0f,
                bounds.top + bounds.height() * 0.56f,
                intArrayOf(0x42FFFFFF, 0x16E9F7FF, 0x00FFFFFF),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(
            bounds.left,
            bounds.top,
            bounds.right,
            bounds.bottom,
            topReflection
        )

        val diagonal = Path().apply {
            moveTo(bounds.left - textSize * 0.10f, bounds.top + bounds.height() * 0.33f)
            cubicTo(
                bounds.left + bounds.width() * 0.25f,
                bounds.top + bounds.height() * 0.12f,
                bounds.left + bounds.width() * 0.33f,
                bounds.top + bounds.height() * 0.18f,
                bounds.left + bounds.width() * 0.47f,
                bounds.top + bounds.height() * 0.30f
            )
        }
        val reflectionStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = textSize * 0.017f
            strokeCap = Paint.Cap.ROUND
            color = 0xA8FFFFFF.toInt()
        }
        canvas.drawPath(diagonal, reflectionStroke)

        val secondary = Path().apply {
            moveTo(bounds.left + bounds.width() * 0.57f, bounds.bottom - bounds.height() * 0.15f)
            cubicTo(
                bounds.left + bounds.width() * 0.72f,
                bounds.bottom - bounds.height() * 0.28f,
                bounds.left + bounds.width() * 0.84f,
                bounds.bottom - bounds.height() * 0.23f,
                bounds.right + textSize * 0.04f,
                bounds.bottom - bounds.height() * 0.36f
            )
        }
        reflectionStroke.strokeWidth = textSize * 0.008f
        reflectionStroke.color = 0x699FE7FF
        canvas.drawPath(secondary, reflectionStroke)

        // A faint cool lower-half refraction tint.
        val lowerTint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f,
                bounds.centerY(),
                0f,
                bounds.bottom,
                intArrayOf(0x001B8CFF, 0x2B6C4DDA),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(bounds, lowerTint)
        canvas.restoreToCount(save)
    }

    private fun drawSmallLensFlares(canvas: Canvas, width: Float, height: Float) {
        val flarePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x8FEAFBFF.toInt()
            strokeWidth = width * 0.0023f
            strokeCap = Paint.Cap.ROUND
            style = Paint.Style.STROKE
        }
        val firstX = width * 0.21f
        val firstY = height * 0.505f
        canvas.drawLine(firstX - width * 0.012f, firstY, firstX + width * 0.012f, firstY, flarePaint)
        canvas.drawLine(firstX, firstY - width * 0.012f, firstX, firstY + width * 0.012f, flarePaint)

        flarePaint.color = 0x79B49BFF
        val secondX = width * 0.79f
        val secondY = height * 0.565f
        canvas.drawLine(secondX - width * 0.009f, secondY, secondX + width * 0.009f, secondY, flarePaint)
        canvas.drawLine(secondX, secondY - width * 0.009f, secondX, secondY + width * 0.009f, flarePaint)
    }
}
