# No custom obfuscation rules are needed for this small offline application.
